extends Button

@export var description : String = "Una hoja con algo escrito... parece importante."

func _ready():
	pressed.connect(_on_pressed)

func _on_pressed():
	var box = get_node("/root/Main/Control/DescriptionBox")
	var text = box.get_node("descripcion")
	
	text.text = description
	box.visible = true
