# En DescriptionBox (Panel)
extends Panel

func _on_gui_input(event):
	if event is InputEventScreenTouch and event.pressed:
		visible = false
